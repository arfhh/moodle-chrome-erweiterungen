(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function n(){"use strict";let e=t.runtime.getManifest?t.runtime.getManifest().version:``,n=new URLSearchParams(location.search);if(n.get(`mode`)!==`grading`||n.get(`slot`)||n.get(`includeauto`)===`1`)return;let r=n.get(`id`);if(!r)return;let i=location.origin+location.pathname,a=(()=>{let e=location.pathname;for(let t of[`/mod/`,`/question/`,`/grade/`,`/course/`,`/admin/`,`/report/`,`/user/`]){let n=e.indexOf(t);if(n>-1)return location.origin+e.slice(0,n)}return location.origin})(),o=e=>{let t=parseFloat(String(e??``).replace(`,`,`.`));return isNaN(t)?null:t},s=e=>Number(e).toFixed(2).replace(`.`,`,`),c=e=>String(Number(e)).replace(`.`,`,`),l=e=>String(e).replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`);function u(e,t,n){if(!e||typeof e!=`object`)return``;let r=t=>String(e[t]||``).trim(),i=r(`lob`),a=[[`Inhalt`,r(`inhalt`)],[`Rechtschreibung`,r(`rechtschreibung`)],[`Grammatik`,r(`grammatik`)],[`Tipp`,r(`tipp`)]].filter(([,e])=>e);if(!a.length&&!i)return``;if(!a.length)return`<p><strong><u>Feedback:</u></strong> `+l(i)+`</p>`;let o=a.map(([e])=>e),c=o.includes(`Grammatik`)?`Grammatik`:o.includes(`Rechtschreibung`)?`Rechtschreibung`:null,u=e=>`<span style="color:#767676;font-style:italic;"> (`+e+`)</span>`,d=!!(n&&n.gewicht>=5),f=e=>e>=5?`5 oder mehr Fehlerpunkte`:e===1?`1 Fehlerpunkt`:e+` Fehlerpunkte`,p=`<p><strong><u>Feedback</u></strong></p>`;return i&&(p+=`<p>`+l(i)+`</p>`),a.forEach(([e,r])=>{let i=``;n&&(e===`Inhalt`&&n.inhalt!=null?i=u(n.inhaltMax==null?s(n.inhalt)+` Punkte`:s(n.inhalt)+` von `+s(n.inhaltMax)+` Punkten`):e===c&&n.abzug&&(i=u(`−`+s(n.abzug)+` Punkte`+(n.gewicht==null?``:` — `+f(n.gewicht)+(d?`, höchste Stufe`:``))))),p+=`<p><u>`+e+`:</u> `+l(r)+i+`</p>`,e===`Inhalt`&&t&&(p+=`<p><u>So hättest du es schreiben können:</u> `+l(t)+`</p>`),e===c&&d&&(p+=`<p>Das sind mehrere grundlegende Fehler in einem einzigen Satz, nicht nur Kleinigkeiten — das ist auf unserer Skala die höchste Fehlerstufe. Bis zum Abitur in zwei bis drei Jahren musst du das sicher beherrschen. Arbeite gezielt daran.</p>`)}),p}function d(e){let t=String(e||``).replace(/\r/g,``).match(/Kernaussage\s*:?\s*([\s\S]*?)(?=\n\s*(?:Muss enthalten|Auch richtig|Inhalt|Reicht nicht|Häufiger Fehler)\s*:|$)/i),n=t?t[1].replace(/\s+/g,` `).trim():``;return n.length>300?``:n}let f=(e,t,n)=>{let r=document.createElement(e);return t&&(r.className=t),n!=null&&(r.textContent=n),r};async function p(e){let t=await fetch(e,{credentials:`same-origin`});if(!t.ok)throw Error(`HTTP `+t.status);return new DOMParser().parseFromString(await t.text(),`text/html`)}let m=e=>new Promise(t=>setTimeout(t,e)),h=(e,t,n)=>`${i}?id=${r}&mode=grading&slot=${e}&qid=${t}&grade=${n||`needsgrading`}&qperpage=100`,g=e=>`${a}/question/bank/editquestion/question.php?id=${e}&cmid=${r}`,_=e=>e&&e.slot&&e.qid?h(e.slot,e.qid,`all`)+(e.qubaid?`#question-`+e.qubaid+`-`+e.slot:``):null;async function v(e){try{await navigator.clipboard.writeText(e)}catch{let t=f(`textarea`,`co-fallback`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),t.remove()}}let y=`[moodle-ai-coach]`,b=/^\s*[\[(]?\s*moodle[-\s]?ai[-\s]?(coach|grader)\s*[\])]?\s*[:.–-]?\s*/i;function x(e){return String(e||``).split(`
`).map(e=>e.trim()).find(Boolean)||``}function ee(e){let t=x(e).match(b);return t?t[1].toLowerCase():null}function S(e){let t=String(e||``).split(`
`),n=t.findIndex(e=>e.trim());return n>-1&&b.test(t[n])&&(t[n]=t[n].replace(b,``).trim(),t[n]||t.splice(n,1)),t.join(`
`).trim()}let C=/^\s*\[?\s*rechtschreibung\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)\s*%?\s*\]?\s*$/i;function w(e){return`[Rechtschreibung: ${c(e)}%]`}function te(e){let t=x(S(e)).match(C);return t?parseFloat(t[1].replace(`,`,`.`)):null}function ne(e){let t=S(e).split(`
`),n=t.findIndex(e=>e.trim());return n>-1&&C.test(t[n].trim())&&t.splice(n,1),t.join(`
`).trim()}function re(e,t){let n=e.split(`
`),r=(n[1]||``).trim();return C.test(r)?e:(n.splice(1,0,w(t)),n.join(`
`))}let T=`Dieses Feedback wurde von der Lehrkraft mithilfe von KI-Unterstützung erstellt und geprüft.`,E={maxSprachabzug:30,kiHinweisText:T,promptOverride:``,horizontPromptOverride:``,nurMitMarker:!1,kompaktPrompt:!1},D={...E},O=!1;function ie(e){let t=D.maxSprachabzug??E.maxSprachabzug;return O?t:(e&&e.horizontProzent)??t}function ae(){return new Promise(e=>{try{t.storage.local.get([`coachOptionen`],t=>{D={...E,...t&&t.coachOptionen?t.coachOptionen:{}},e(D)})}catch{e(D)}})}function k(e){return D={...D,...e},new Promise(e=>{try{t.storage.local.set({coachOptionen:D},e)}catch{e()}})}let oe=[0,1/3,1/2,2/3,5/6,1];function se(e,t){let n=Math.min(Math.max(0,Math.round(e)),oe.length-1),r=t??D.maxSprachabzug??E.maxSprachabzug;return oe[n]*r}let ce=e=>(e||[]).reduce((e,t)=>e+(t&&t.schwer?2:1),0);function le(e,t,n,r){let i=ce(n),a=se(i,r),o=e*t/100-e*a/100;return{gewicht:i,abzug:a,inhaltPunkte:Math.round(e*t/100*100)/100,abzugPunkte:Math.round(e*a/100*100)/100,punkte:Math.max(0,Math.round(o*100)/100)}}function ue(){let e=document.querySelector(`table`);return e?[...e.querySelectorAll(`tbody tr`)].map(e=>{let t=[...e.querySelectorAll(`a`)].map(e=>e.getAttribute(`href`)||``).find(e=>/slot=/.test(e))||``,n=(t.match(/slot=(\d+)/)||[])[1],r=(t.match(/qid=(\d+)/)||[])[1];if(!n||!r)return null;let i=(e.cells[5]?e.cells[5].textContent.trim():``).match(/^(\d+)/);return{slot:n,qid:r,name:e.cells[2]?e.cells[2].textContent.trim():``,summe:i?+i[1]:null}}).filter(Boolean):[]}let de=e=>e?e.innerHTML.replace(/<[^>]+>/g,` `).replace(/&nbsp;/g,` `).replace(/&amp;/g,`&`).replace(/&lt;/g,`<`).replace(/&gt;/g,`>`).replace(/&quot;/g,`"`).replace(/\s+/g,` `).trim():``,fe=e=>e.querySelector(`textarea.qtype_essay_response, div.qtype_essay_response`),pe=e=>(e.tagName===`TEXTAREA`?e.value||``:de(e)).trim();async function me(e,t){let n=null,r=new Set,i=[];for(let a=0;a<t;a++){a>0&&await m(500);let t=await p(h(e.slot,e.qid,`all`));if(n=t,[...t.querySelectorAll(`.que`)].forEach(e=>{let t=(e.id||``).match(/^question-(\d+)-(\d+)$/),n=t?t[1]:e.id;n&&!r.has(n)&&(r.add(n),i.push(e))}),e.summe!=null&&i.length>=e.summe)break}return{bloecke:i,letzterDoc:n}}async function he(e,t){if(!e.length||!e.some(e=>fe(e)))return null;let n=e[0],r=n.querySelector(`.graderinfo`),i=r?r.innerText.trim():``,a=Se(n),s=null;if(a&&a.gesamt>a.ist)try{let e=await Ce(t.qid);e&&e.horizont&&(i=e.horizont,s=a.gesamt)}catch{}let c={name:t.name,qid:t.qid,slot:t.slot,aufgabe:de(n.querySelector(`.qtext`)),zustaendig:ee(i),horizontProzent:te(i),horizont:ne(i),max:o((n.querySelector(`input[name$="-maxmark"]`)||{}).value)??1,...s?{horizont_aus_fassung:s}:{}},l=[];return e.forEach(e=>{let n=(e.id||``).match(/^question-(\d+)-(\d+)$/);if(!n)return;let r=fe(e),i=e.querySelector(`input[name$="-mark"]`),a=e.querySelector(`textarea[name$="-comment"]`);if(!r||!i)return;let s=String(i.value||``).trim()!==``;l.push({frage:t.name,qid:t.qid,slot:t.slot,qubaid:n[1],antwort:pe(r),max:o((e.querySelector(`input[name$="-maxmark"]`)||{}).value)??c.max,markfeld:i.name,kommentarfeld:a?a.name:null,hat_kommentar:!!(a&&a.value.trim()),schon_bewertet:s})}),{frage:c,versuche:l}}async function ge(e,t){let n=ue();if(!n.length)throw Error(`Auf dieser Seite steht keine Fragenübersicht.`);let i={},a={},o=[],s=[],c=0,l=0,u=0,d=0,f=0,p=0,m=0,h=[...n];return await Promise.all(Array.from({length:1},async()=>{for(;h.length;){let r=h.shift();try{let{bloecke:e}=await me(r,8),n=await he(e,r);if(!n)d++;else{let e=n.frage.name||r.slot+`|`+r.qid,s=n.frage.zustaendig,c=s===`grader`,d=D.nurMitMarker&&s!==`coach`;c||d?a[e]||(a[e]={...n.frage,grund:c?`grader`:`kein-marker`},c?f++:m++):(i[e]||(i[e]=n.frage,n.frage.horizont?s||p++:u++),n.versuche.forEach(e=>{if(e.schon_bewertet&&!t){l++;return}o.push(e)}))}}catch(e){s.push({frage:r.name,meldung:e.message})}c++,e(c,n.length,o.length)}})),o.forEach((e,t)=>{e.nr=t+1}),{meta:{test:(document.title||``).replace(/\s*\|.*$/,``).trim(),kurs:(()=>{let e=[...document.querySelectorAll(`a`)].find(e=>/\/course\/view\.php/.test(e.getAttribute(`href`)||``));return e?e.textContent.trim():``})(),cmid:r,datum:new Date().toISOString().slice(0,10),fragen_geprueft:n.length,fragen_mit_horizont:Object.values(i).filter(e=>e.horizont).length,fragen_ohne_horizont:u,fragen_fuer_grader:f,fragen_ohne_marker:p,streng_uebersprungen:m,nur_mit_marker:!!D.nurMitMarker,keine_freitextfrage:d,antworten:o.length,uebersprungen:l,max_sprachabzug_prozent:D.maxSprachabzug},fragen:i,fremde:a,antworten:o,fehler:s}}function A(e){let t=new URLSearchParams;return[...e.elements].forEach(e=>{e.name&&!e.disabled&&[`INPUT`,`SELECT`,`TEXTAREA`].includes(e.tagName)&&e.type!==`file`&&e.type!==`submit`&&(e.type!==`checkbox`&&e.type!==`radio`||e.checked)&&(e.tagName===`SELECT`?[...e.selectedOptions].forEach(n=>t.append(e.name,n.value)):t.append(e.name,e.value))}),t}function _e(e){let t=new Map;return(e||[]).forEach(e=>{let n=e.slot+`|`+e.qid;t.has(n)||t.set(n,{slot:e.slot,qid:e.qid,eintraege:[]}),t.get(n).eintraege.push(e)}),[...t.values()]}async function ve(e,t,n){let r=_e(e),i=0,a=0,o=0;for(let e of r){try{let n=(await p(h(e.slot,e.qid,`all`))).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);let r=A(n);e.eintraege.forEach(e=>{let n=[];r.has(e.markfeld)||n.push(`Punktefeld`),e.text&&e.kommentarfeld&&!r.has(e.kommentarfeld)&&n.push(`Kommentarfeld`),n.length?(a++,t(`✗ ${n.join(` und `)} fehlt — ${e.frage}`,_(e))):i++})}catch(n){a+=e.eintraege.length,t(`✗ Seite ${e.eintraege[0].frage}: ${n.message}`)}o++,n(o,r.length)}return{ok:i,fehler:a,gruppen:r.length,trocken:!0}}async function ye(e,t,n){let r=null,i=new URLSearchParams,a=new Set;for(let o=0;o<n;o++){o>0&&await m(500);let n=(await p(e)).querySelector(`form#manualgradingform`);if(!n)throw Error(`Bewertungsformular nicht gefunden`);r=n;let s=A(n);if([...new Set(s.keys())].forEach(e=>{a.has(e)||(i.set(e,s.get(e)),a.add(e))}),t.every(e=>i.has(e)))break}return{form:r,felder:i}}async function be(e,t,n,r){let i=_e(e),a=0,c=0,u=0,d=[];for(let e of i){try{let r=h(e.slot,e.qid,`all`),{form:i,felder:u}=await ye(r,e.eintraege.map(e=>e.markfeld),8),f=u,g=[];if(e.eintraege.forEach(e=>{if(!f.has(e.markfeld)){c++,d.push(e),n(`✗ Punktefeld nicht auf der Seite — ${e.frage}`,_(e));return}if(f.set(e.markfeld,s(e.punkte)),e.text&&e.kommentarfeld&&f.has(e.kommentarfeld)){let n=e.text.trim();if(/<[a-z]/i.test(n)||(n=`<p>`+n.replace(/\n+/g,`</p><p>`)+`</p>`),t){let e=(D.kiHinweisText||T).trim();e&&(n+=`<p><em><small>`+l(e)+`</small></em></p>`)}f.set(e.kommentarfeld,n)}g.push(e)}),g.length){let e=[...i.elements].find(e=>e.type===`submit`&&e.name);e&&f.set(e.name,e.value);let t=new URL(i.getAttribute(`action`)||r,r).href,l=await fetch(t,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:f.toString()});if(!l.ok)throw Error(`HTTP `+l.status+` beim Speichern`);let u=g.slice(),h=new Map;for(let e=0;e<8&&u.length;e++){e>0&&await m(500);let t=await p(r);u=u.filter(e=>{let n=t.querySelector(`input[name="${CSS.escape(e.markfeld)}"]`),r=n?o(n.value):null;return r!==null&&Math.abs(r-e.punkte)<.005?(h.set(e,r),!1):(h.set(e,r),!0)})}g.forEach(e=>{if(!u.includes(e))a++,n(`✓ ${e.frage} — ${s(e.punkte)} von ${s(e.max)}`,_(e));else{c++,d.push(e);let t=h.get(e);n(`✗ ${e.frage} — steht auf ${t==null?`keinem Wert`:s(t)} statt ${s(e.punkte)}`,_(e))}})}}catch(t){c+=e.eintraege.length,d.push(...e.eintraege),n(`✗ ${e.eintraege[0].frage}: ${t.message}`)}u++,r(u,i.length)}return{ok:a,fehler:c,gruppen:i.length,fehlgeschlagen:d}}async function xe(e,t,n,r){let i=e,a=0,o=0,s=0;for(let e=1;e<=3&&i.length;e++){s=e,e>1&&(n(`↻ Versuch ${e}/3: ${i.length} Eintrag/Einträge erneut …`),await m(1500));let c=await be(i,t,n,r);a+=c.ok,o+=c.gruppen,i=c.fehlgeschlagen}return{ok:a,fehler:i.length,gruppen:o,versuche:s}}function Se(e){let t=[...e.querySelectorAll(`.badge, .info span`)].map(e=>e.textContent.trim()).find(e=>/^v\d+\s*\(von\s*\d+\)$/i.test(e)),n=t&&t.match(/^v(\d+)\s*\(von\s*(\d+)\)$/i);return n?{ist:+n[1],gesamt:+n[2]}:null}async function Ce(e){let t=[...(await p(g(e))).querySelectorAll(`a`)].find(e=>/history\.php/.test(e.getAttribute(`href`)||``));if(!t)return null;let n=[...(await p(new URL(t.getAttribute(`href`),g(e)).href)).querySelectorAll(`table tbody tr`)];if(!n.length)return null;let r=null;for(let e of n)for(let t of e.querySelectorAll(`a`)){let e=(t.getAttribute(`href`)||``).match(/question\.php\?[^"']*?\bid=(\d+)/);if(e){r=e[1];break}}if(!r||String(r)===String(e))return null;let i=(await p(g(r))).querySelector(`[name="graderinfo[text]"]`);if(!i)return null;let a=document.createElement(`div`);a.innerHTML=String(i.value||``);let o=a.innerText.trim();return o?{qid:r,horizont:o}:null}function we(e,t,n){let r=re(b.test(x(t))?t:y+`
`+t,D.maxSprachabzug??E.maxSprachabzug);return j(e,()=>`<p>`+l(r).replace(/\n/g,`<br>`)+`</p>`,r,n)}function Te(e){let t=`<p>`+y+`</p><p>`+w(D.maxSprachabzug??E.maxSprachabzug)+`</p>`;return j(e,e=>t+(e||``),y,!1)}async function j(e,t,n,r){let i=g(e),a=await p(i),o=[...a.forms].find(e=>e.querySelector(`[name="graderinfo[text]"]`))||[...a.forms].find(e=>e.querySelector(`[name*="graderinfo"]`));if(!o)throw Error(a.querySelector(`form#login`)?`Moodle hat auf die Anmeldeseite umgeleitet — bist du noch angemeldet?`:`Bearbeiten-Formular nicht gefunden (ist es eine Freitextfrage?)`);let s=A(o),c=`graderinfo[text]`;if(!s.has(c))throw Error(`Feld „graderinfo[text]" nicht im Formular`);if(r)return{ok:!0,feld:c,vorher:s.get(c)||``};s.set(c,t(s.get(c)||``));let l=[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name===`submitbutton`)||[...o.querySelectorAll(`input[type=submit],button[type=submit]`)].find(e=>e.name&&e.name!==`cancel`);if(!l)throw Error(`Kein Speichern-Knopf im Formular`);s.set(l.name,l.value);let u=new URL(o.getAttribute(`action`)||i,i).href,d=await fetch(u,{method:`POST`,credentials:`same-origin`,headers:{"Content-Type":`application/x-www-form-urlencoded`},body:s.toString()});if(!d.ok)throw Error(`HTTP `+d.status+` beim Speichern`);let f=null;try{f=new URL(d.url).searchParams.get(`lastchanged`)}catch{}let m=(await p(f?g(f):i)).querySelector(`[name="${CSS.escape(c)}"]`),h=m?String(m.value||``).replace(/<[^>]*>/g,` `).replace(/\s+/g,` `).trim():``,_=String(n).replace(/\s+/g,` `).trim().slice(0,30);if(!h||!h.includes(_.slice(0,20)))throw Error(f?`Text nicht angekommen (geprüft an der neuen Fragenversion)`:`Nicht gegengeprüft: Moodle hat keine neue Fragen-Nummer zurückgemeldet. Sieh in der Frage selbst nach — gespeichert sein kann es trotzdem.`);return{ok:!0,feld:c,neueId:f}}let M=`[MOODLE_AI_COACH_DATEN]`;function N(){return`═══════════════════════════════════════════════════════
MOODLE AI COACH – BEWERTUNG KURZER FREITEXTANTWORTEN
═══════════════════════════════════════════════════════

BEGRÜSSUNG
Beginne mit genau diesen drei Punkten, dann folge den Arbeitsanweisungen:
1. „Willkommen beim Moodle AI Coach."
2. „Ich bewerte kurze Freitextantworten nach dem Erwartungshorizont, der in der
   Aufgabe hinterlegt ist, und schreibe jedem Schüler eine Rückmeldung zur Sprache.
   Entscheiden tust du."
3. „Der „Moodle AI Coach" wurde von A. Spielhoff entwickelt und ist unter der Lizenz
   CC BY-SA 4.0 veröffentlicht – du darfst ihn frei verwenden, teilen und anpassen,
   solange du ihn nennst."

═══════════════════════════════════════════════════════
AUSGANGSLAGE
═══════════════════════════════════════════════════════

Die Schülerinnen und Schüler haben eine Frage in ein bis drei Sätzen beantwortet.
Zu jeder Aufgabe steht unter „horizont" der Erwartungshorizont der Lehrkraft: die
Kernaussage, was enthalten sein muss, was auch als richtig gilt und – am wichtigsten –
eine Abstufung, welcher Prozentsatz wofür vergeben wird.

Deine Aufgabe hat zwei Teile, die STRIKT getrennt bleiben:
  1. INHALT  – wie gut trifft die Antwort den Erwartungshorizont?
  2. SPRACHE – welche Sprachfehler stehen im Text?

═══════════════════════════════════════════════════════
TEIL 1 – INHALT
═══════════════════════════════════════════════════════

Vergib einen Prozentwert nach der Abstufung, die im Horizont unter „Inhalt:" steht.
Halte dich an diese Stufen. Erfinde keine Zwischenwerte und keine eigene Skala –
die Lehrkraft hat für diese Aufgabe bereits entschieden.

Steht im Horizont ausnahmsweise keine Abstufung, benutze 100 / 75 / 50 / 25 / 0.

Grundregeln:
• Bewerte nur, was tatsächlich dasteht. Interpretiere nichts hinein.
• „Auch richtig" im Horizont ist verbindlich: Wer eine dort genannte Formulierung
  benutzt, bekommt die volle Stufe – auch umgangssprachlich.
• Fachlich richtige Zusätze, die nicht verlangt waren, geben keine Punkte, kosten
  aber auch keine.
• Eine Antwort in Stichworten statt in Sätzen ist inhaltlich nicht schlechter.
  Der Satzbau wird in Teil 2 bewertet, nicht hier.

═══════════════════════════════════════════════════════
TEIL 2 – SPRACHE
═══════════════════════════════════════════════════════

Du zählst die Fehler. Den Abzug rechnet die Erweiterung daraus selbst aus –
schreibe nirgends einen Abzug oder eine Punktzahl hin.

Zähle als Fehler, was eine strenge Deutschlehrkraft anstreichen würde:

SCHWER (zählt doppelt):
  • Satz ohne Prädikat oder abgebrochener Satz
  • Satzbau so falsch, dass man den Satz zweimal lesen muss

NORMAL (zählt einfach):
  • falscher Fall oder falscher Numerus („die Atome verbindet sich")
  • falsche Zeitform
  • Nomen kleingeschrieben oder Verb großgeschrieben
  • Fachbegriff falsch geschrieben
  • sonstiger Rechtschreibfehler
  • fehlender Punkt am Satzende oder fehlendes Komma vor dem Nebensatz
  • Umgangssprache statt Fachsprache („das Zeug", „macht kaputt")

Zählregeln:
• Derselbe Fehler im selben Wort zählt nur einmal, auch wenn das Wort mehrfach
  vorkommt.
• Zähle nur, was du benennen kannst. Ein Bauchgefühl ist kein Fehler.
• Eine leere Antwort hat keine Sprachfehler – dort ist der Inhalt 0 %.

Zur Einordnung, was mit deiner Zählung geschieht: Der Höchstabzug ist gerade auf
${D.maxSprachabzug??E.maxSprachabzug} % der Aufgabenpunkte eingestellt. 1 Fehler kostet ein Drittel davon,
2 Fehler die Hälfte, 3 zwei Drittel, 4 fünf Sechstel, ab 5 den vollen Abzug.

═══════════════════════════════════════════════════════
TEIL 3 – RÜCKMELDUNG
═══════════════════════════════════════════════════════

Das Feedback ist das eigentliche Produkt. Es lesen Schülerinnen und Schüler der
Mittelstufe, viele davon schreibschwach. Sie sollen daraus lernen — also schreibst du
wie eine Deutschlehrkraft, die einem Vierzehnjährigen etwas erklärt.

SPRACHE — so schreibst du:
• Kurze Hauptsätze. Ein Gedanke pro Satz. KEINE verschachtelten Sätze.
• Sag die Regel, nicht nur die Korrektur.
  Schwach: „Der Name wird großgeschrieben."
  Gut:     „Vor „Löschsand" kannst du „der" setzen. Solche Wörter sind Nomen. Nomen
            schreibt man groß: Löschsand."
• Stell falsch und richtig direkt gegenüber: löchsand → Löschsand.
  Lange Satzzitate sind für schwache Leser schwerer als ein Wortpaar.
• Kein Fachjargon ohne Erklärung. „Nomen", „Satzende", „Komma" sind bekannt;
  „Prädikat", „Kasus", „Numerus" erklärst du in eigenen Worten.
• Höchstens zwei Korrekturen je Zeile. Der Rest bleibt ungesagt — lieber weniger,
  das dafür verstanden.
• Freundlich und sachlich. Keine Floskeln, keine Emojis, kein Ausrufezeichen-Gewitter.

GLIEDERUNG — du schreibst KEINEN Fließtext, sondern füllst Felder:
Aus ihnen baut die Erweiterung selbst das fertige Feedback mit Überschrift, Umbrüchen
und Unterstreichungen. Schreib deshalb nirgends HTML, keine Sternchen, keine Zeilen-
umbrüche in die Felder.

  lob             – nur bei 95 % und mehr der Punkte: ein Satz Anerkennung,
                    konkret auf die Aufgabe bezogen („Du hast die Aufgabe zum
                    Löschsand richtig gut beantwortet.")
  inhalt          – was inhaltlich fehlte oder falsch war, und wie es richtig heißt.
                    Bei voller Punktzahl: was genau gut war.
  rechtschreibung – nur Rechtschreibung: Groß- und Kleinschreibung, falsch
                    geschriebene Wörter. Mit der Regel dahinter.
  grammatik       – nur Satzbau und Zeichensetzung: fehlende Punkte und Kommas,
                    Sätze ohne Trennung, falsche Fälle und Zeitformen.
  tipp            – freiwillig: EIN Merksatz für das nächste Mal. Nur, wenn er wirklich
                    hilft. Nicht bei jeder Antwort.

Felder, zu denen es nichts zu sagen gibt, lässt du weg. Eine Antwort ohne
Rechtschreibfehler bekommt keine Zeile „Rechtschreibung".

DIE DREI FÄLLE:

1. Volle Punktzahl, keine Sprachfehler → NUR das Feld „lob", sonst nichts.
   Beispiel: lob = „Das hast du super beantwortet — Name und Funktion sind richtig."

2. 95 % oder mehr, aber eine Kleinigkeit → zuerst „lob", dann die eine Zeile, die es
   betrifft. Erst loben, dann verbessern.
   Beispiel: lob = „Du hast die Aufgabe zum Löschsand richtig gut beantwortet."
             grammatik = „Am Satzende fehlt der Punkt."

3. Unter 95 % → kein Lob-Feld. Zuerst „inhalt", dann Rechtschreibung und Grammatik,
   wo nötig.

Die Musterlösung schreibst du NICHT. Liegt die Antwort unter 100 %, hängt die
Erweiterung von sich aus die Zeile „So hättest du es schreiben können: …" an und setzt
dort die Kernaussage aus dem Erwartungshorizont ein — wörtlich das, was die Lehrkraft
hinterlegt hat. Im Feld „inhalt" steht deshalb nur, WAS fehlte oder falsch war, nicht
die fertige Lösung.

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert. Je Frage eine Kopfzeile mit der
Aufgabe und der Kernaussage aus dem Horizont, darunter die Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|
| 1 | „Hefe wandelt Zucker in Alkohol um" | 50 | 1 normal | Prozess nicht benannt |

• „Nr" ist die Zahl aus dem Feld „nr" – nicht deine eigene Zählung.
• „Sprachfehler": Anzahl und Art, zum Beispiel „2 normal, 1 schwer".
• „Begründung": ein Halbsatz, der sich auf die Abstufung im Horizont bezieht.
• Keine Punkte- und keine Abzugsspalte. Das rechnet die Erweiterung.

Halte danach an und schreibe:
„Passt das so? Nenne mir die Nummern, die ich ändern soll, zum Beispiel: 3 auf 75.
Wenn alles stimmt, antworte mit ok – dann gebe ich dir das JSON aus."

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok":

\`\`\`json
{
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "Du hast geschrieben, dass Hefe Zucker umwandelt. Das stimmt. Es fehlt, was dabei entsteht: Alkohol und Kohlenstoffdioxid.",
        "rechtschreibung": "Vor „Zucker" kannst du „der" setzen. Solche Wörter sind Nomen, und Nomen schreibt man groß: Zucker.",
        "grammatik": "Am Satzende fehlt der Punkt."
      } },
    { "frage": "Löschsand (AFB I)", "qubaid": "2433020", "slot": "6",
      "inhalt": 100, "fehler": [],
      "rueckmeldung": { "lob": "Das hast du super beantwortet — Name und Funktion sind richtig." } }
  ]
}
\`\`\`

• Ein Eintrag je Versuch. „qubaid" und „slot" unverändert aus den Daten.
• „inhalt" ist der Prozentwert aus der Abstufung des Horizonts.
• „fehler" ist die Liste der gezählten Sprachfehler, leer bei fehlerfreiem Text.
• „rueckmeldung" enthält die Felder aus Teil 3. Nur die füllen, zu denen es etwas zu
  sagen gibt; leere Felder ganz weglassen. Jedes Feld ist ein oder zwei ganze Sätze,
  ohne Zeilenumbruch und ohne Formatierungszeichen — Überschrift, Absätze und
  Unterstreichungen setzt die Erweiterung selbst.
• JEDER Eintrag bekommt eine Rückmeldung, auch die fehlerfreien: dort steht das
  Lob-Feld allein.
• Keine Punktzahlen, kein Abzug, keine Feldnamen.
• WICHTIG – Anführungszeichen im JSON: Willst du in einem Rückmeldungstext ein Wort
  hervorheben oder ein Zitat setzen, benutze dafür EINFACHE Anführungszeichen ('so')
  oder schreibe es ohne Anführungszeichen. Gerade doppelte Anführungszeichen ("so")
  NIEMALS in einem JSON-Textfeld verwenden – das ist dasselbe Zeichen wie die
  JSON-Begrenzung und macht das ganze JSON kaputt. Das ist schon mehrfach passiert.

Schreibe darunter: „Kopiere diesen Block in die Erweiterung, Reiter „2 · Eintragen",
und klicke dort auf „🔍 Prüfen"."

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Hat die Lehrkraft in Schritt 1 Prozentwerte geändert, ist das mehr als eine
Einzelfallentscheidung: Der Horizont bildet ihren Maßstab an dieser Stelle nicht ab
und würde beim nächsten Durchgang denselben Fehler wieder erzeugen.

Deshalb NACH dem JSON – aber nur, wenn tatsächlich korrigiert wurde:

1. Nenne je betroffener Frage in einem Satz, welche Regel sich aus der Korrektur
   ergibt. Nicht „Nr. 7 wurde auf 100 gesetzt", sondern die dahinterliegende
   Entscheidung: „Beim Löschsand reicht ‚löscht Brände' für 100 % – der Metallbrand
   muss nicht genannt werden."
2. Sag dazu, was sich im Horizont ändern müsste: meist wandert ein Teilaspekt von
   „Muss enthalten" nach „Auch richtig", und die betroffene Prozentstufe entfällt
   oder wird neu beschrieben.
3. Biete an, die Horizonte dieser Fragen neu zu schreiben, mit dem Weg dorthin:
   „Reiter 3 · Horizont, Häkchen ‚Auch Fragen einbeziehen, die schon einen Horizont
   haben' setzen, Prompt kopieren – ich baue die Korrekturen dann direkt ein."
4. Merke dir die Korrekturen für diesen Fall, damit sie in den neuen Horizont
   einfließen, wenn der Horizont-Prompt gleich nachkommt.

Wurde nichts geändert, lässt du diesen Schritt ersatzlos weg – kein „hier gab es
nichts zu korrigieren".

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

- „fragen"    – je Frage: Aufgabentext, Maximalpunkte und der Erwartungshorizont
                aus dem Moodle-Feld „Bewerterinformation".
- „antworten" – je Versuch die Schülerantwort mit „nr", „qubaid" und „slot".

${M}`}function P(){return`═══════════════════════════════════════════════════════
MOODLE AI COACH – ERWARTUNGSHORIZONT ERSTELLEN
═══════════════════════════════════════════════════════

Für die unten stehenden Aufgaben brauchst du einen Erwartungshorizont – einen je
Aufgabe, in genau dem Format unten. Er wird anschließend in das Moodle-Feld
„Bewerterinformation" der Frage geschrieben und dort dauerhaft benutzt.

Steht bei einer Aufgabe „horizont_bisher", gibt es dort schon einen. Er ist der
**Ausgangspunkt, keine Vorlage zum Abschreiben**: Er wird ersetzt, weil an ihm etwas
nicht stimmt. Übernimm, was gut ist, und weiche dort ab, wo die Änderungswünsche der
Lehrkraft es verlangen – auch dann, wenn der bisherige Horizont das Gegenteil sagt.
Steht kein „horizont_bisher" dabei, schreibst du neu.

Die Kernaussage bekommen die Schülerinnen und Schüler zu sehen: Die Erweiterung setzt
sie bei unvollständigen Antworten als „So hättest du es schreiben können" unter die
Rückmeldung. Schreib sie deshalb als vollständige Musterantwort in einfacher Sprache –
Name und Funktion, ein bis zwei kurze Sätze.

WICHTIG – was NICHT hineingehört:
Keine Sprachregeln, kein Rechtschreibabzug, kein Feedback-Stil, keine Rolle, keine
Punktzahl. Das steht global in der Erweiterung. Im Horizont steht ausschließlich,
was für DIESE eine Aufgabe gilt. Sonst entstehen so viele Kopien der Regeln, wie es
Fragen gibt, und sie laufen auseinander.

FORMAT je Aufgabe:

Erwartungshorizont

Kernaussage:
<der eine Satz, der die volle Inhaltspunktzahl trägt>

Muss enthalten:
- <Teilaspekt 1>
- <Teilaspekt 2>

Auch richtig:
<gleichwertige Formulierungen, Synonyme, umgangssprachliche Varianten>

Inhalt:
100 % – <Bedingung>
 75 % – <Bedingung>            (nur wenn die Aufgabe eine solche Stufe hergibt)
 50 % – <Bedingung>
 25 % – <Bedingung>
  0 % – <Bedingung>

Reicht nicht:
<typische halbe Antwort und warum sie nicht reicht>

Häufiger Fehler:
<typischer Denkfehler – hilft später beim Feedback>

REGELN:
• Benutze nur die Stufen 100 / 75 / 50 / 25 / 0. Kein 90 – das ist im Projekt die
  Rechtschreibstufe und hat mit Inhalt nichts zu tun.
• Lass Stufen weg, die die Aufgabe nicht hergibt. Bei einer Aufzählung von drei
  Dingen sind 100 / 75 / 50 / 0 natürlicher als fünf Stufen.
• Die Antwort soll ein bis drei Sätze lang sein. Halte den Horizont entsprechend
  knapp – er ist kein Lehrbuchtext.
• „Auch richtig" ist der wichtigste Abschnitt. Denk daran, wie Vierzehnjährige
  formulieren, und nimm diese Varianten ausdrücklich auf.
• Der Operator der Aufgabe zählt: Bei „Nenne" reicht die Nennung, bei „Erkläre"
  muss ein Zusammenhang dastehen, bei „Vergleiche" beide Seiten.

AUSGABE:
Gib zuerst alle Horizonte als lesbaren Text aus, damit die Lehrkraft sie prüfen kann.
Frage dann: „Passt das so?"
Erst nach „ok" gibst du sie als JSON aus:

\`\`\`json
{
  "horizonte": [
    { "qid": "115576570", "frage": "alkoholischen Gärung (AFB I)",
      "text": "Erwartungshorizont\\n\\nKernaussage:\\n…" }
  ]
}
\`\`\`

„qid" übernimmst du unverändert aus den Daten unten.

═══════════════════════════════════════════════════════
AUFGABEN OHNE ERWARTUNGSHORIZONT
═══════════════════════════════════════════════════════

[MOODLE_AI_COACH_AUFGABEN]`}function Ee(){return`═══════════════════════════════════════════════════════
MOODLE AI COACH – BEWERTUNG (KOMPAKTER PROMPT)
═══════════════════════════════════════════════════════

Falls du Zugriff auf die Skills „2-didaktik-bewertung“ und „3-moodle-erweiterungen“
von A. Spielhoff hast: Wende deren Bewertungslogik an — Inhalt strikt getrennt von
Sprache, die Abstufung im Horizont ist verbindlich (keine eigene Skala erfinden),
Sprachfehler zählen (schwer = doppelt) statt selbst Punkte abzuziehen, die
Feedback-Gliederung in Felder (lob/inhalt/rechtschreibung/grammatik/tipp) mit
kurzen, schülergerechten Sätzen für die Mittelstufe, und die drei Rückmeldungsfälle
(volle Punktzahl → nur Lob; ≥95 % → Lob zuerst; darunter → kein Lob).

Hast du diese Skills NICHT: Bitte um den ausführlichen Prompt (⚙ → Häkchen
„Kompakter Prompt“ ausschalten) statt zu raten — ohne die genauen Regeln (besonders
die Trennung Inhalt/Sprache und die Feld-Gliederung) sind falsche Bewertungen und
unpassendes Feedback wahrscheinlich.

Höchstabzug für Sprache ist gerade auf ${D.maxSprachabzug??E.maxSprachabzug} % der Aufgabenpunkte eingestellt:
1 Fehler kostet ein Drittel davon, 2 die Hälfte, 3 zwei Drittel, 4 fünf Sechstel,
ab 5 den vollen Abzug. Punkte NICHT selbst ausrechnen, nur Inhalt-Prozent und
Fehlerliste angeben — das rechnet die Erweiterung.

═══════════════════════════════════════════════════════
SCHRITT 1 – TABELLE ZUR PRÜFUNG
═══════════════════════════════════════════════════════

Gib zuerst alle Antworten aus, nach Frage gruppiert, mit Kopfzeile (Aufgabe +
Kernaussage aus dem Horizont), dann eine Tabelle:

| Nr | Antwort (gekürzt) | Inhalt | Sprachfehler | Begründung |
|---|---|---|---|---|

„Nr“ ist die Zahl aus „nr“ im Datensatz. Keine Punkte- und keine Abzugsspalte. Halte
danach an und frage: „Passt das so? Nenne mir die Nummern, die ich ändern soll, zum
Beispiel: 3 auf 75. Wenn alles stimmt, antworte mit ok.“ Warte auf die Antwort.

═══════════════════════════════════════════════════════
SCHRITT 2 – JSON
═══════════════════════════════════════════════════════

Erst nach „ok“ ausgeben:

\`\`\`json
{
  "bewertungen": [
    { "frage": "alkoholischen Gärung (AFB I)", "qubaid": "2433013", "slot": "6",
      "inhalt": 50,
      "fehler": [
        { "art": "Nomen kleingeschrieben", "stelle": "zucker", "schwer": false }
      ],
      "rueckmeldung": {
        "inhalt": "…",
        "rechtschreibung": "…",
        "grammatik": "…"
      } }
  ]
}
\`\`\`

Ein Eintrag je Versuch, „qubaid“/„slot“ unverändert übernehmen. „inhalt“ ist der
Prozentwert aus der Horizont-Abstufung. „fehler“ leer bei fehlerfreiem Text.
„rueckmeldung“ nur die Felder füllen, zu denen es etwas zu sagen gibt (leere Felder
weglassen), jedes ein bis zwei ganze Sätze ohne Formatierung. Musterlösung NICHT
selbst schreiben — das hängt die Erweiterung an. WICHTIG: Hebst du in einem
Rückmeldungstext ein Wort hervor, benutze dafür einfache Anführungszeichen ('so'),
nie gerade doppelte ("so") — die brechen das JSON, weil sie die JSON-Begrenzung
sind. Satz danach: „Kopiere diesen Block
in die Erweiterung, Reiter „2 · Eintragen“, und klicke dort auf „🔍 Prüfen“.“

═══════════════════════════════════════════════════════
SCHRITT 3 – HORIZONT NACHZIEHEN (nur wenn korrigiert wurde)
═══════════════════════════════════════════════════════

Wurden in Schritt 1 Prozentwerte geändert, nenne je betroffener Frage in einem Satz
die dahinterliegende Regel (nicht „Nr. 7 auf 100", sondern z. B. „Beim Löschsand
reicht ‚löscht Brände' für 100 % – der Metallbrand muss nicht genannt werden"), sag
was sich im Horizont ändern müsste, und biete an, die Horizonte über Reiter 3 neu zu
schreiben. Ohne Korrektur diesen Schritt ersatzlos weglassen.

═══════════════════════════════════════════════════════
DATEN AUS MOODLE
═══════════════════════════════════════════════════════

„fragen“ – je Frage: Aufgabentext, Maximalpunkte, Erwartungshorizont aus
„Bewerterinformation“. „antworten“ – je Versuch die Schülerantwort mit „nr“,
„qubaid“, „slot“.

${M}`}function F(e){let t=(D.promptOverride||``).trim()||(D.kompaktPrompt?Ee():N()),n="```json\n"+JSON.stringify(e,null,1)+"\n```";return t.includes(M)?t.replace(M,n):t+`

`+n}function De(e){let t=(D.horizontPromptOverride||``).trim()||P(),n="```json\n"+JSON.stringify(e.map(e=>{let t={qid:e.qid,frage:e.name,aufgabe:e.aufgabe,max:e.max};return e.horizont&&(t.horizont_bisher=S(e.horizont)),t}),null,1)+"\n```",r=String((typeof Z==`function`?Z():``)||``).trim(),i=r?`═══════════════════════════════════════════════════════
ÄNDERUNGSWÜNSCHE DER LEHRKRAFT
═══════════════════════════════════════════════════════

Diese Vorgaben haben Vorrang vor allem, was in „horizont_bisher" steht.
Wo sie einem bisherigen Horizont widersprechen, gilt der Wunsch.

`+r+`

`:``,a=`[MOODLE_AI_COACH_AUFGABEN]`,o=i+n;return t.includes(a)?t.replace(a,o):t+`

`+o}let I=f(`button`,`co-fab`);I.title=`Moodle AI Coach`;try{let e=document.createElement(`img`);e.src=t.runtime.getURL(`icon/128.png`),e.alt=`AI Coach`,e.className=`co-fab-icon`,e.addEventListener(`error`,()=>{e.remove(),I.textContent=`Co`}),I.appendChild(e)}catch{I.textContent=`Co`}document.body.appendChild(I);let L=f(`div`,`co-panel co-hidden`);L.innerHTML=`
    <div class="co-head">
      <span class="co-title">AI Coach <span class="co-version"></span></span>
      <button class="co-close" title="Schließen">✕</button>
    </div>
    <div class="co-tabs">
      <button class="co-tab co-aktiv" data-tab="lesen">1 · Bewerten</button>
      <button class="co-tab" data-tab="eintrag">2 · Eintragen</button>
      <button class="co-tab" data-tab="horizont">3 · Horizont <span class="co-badge co-hidden"></span></button>
      <button class="co-tab" data-tab="opt">⚙</button>
    </div>

    <div class="co-body" data-panel="lesen">
      <p class="co-meta"></p>
      <label class="co-check"><input type="checkbox" class="co-bereits">
        Auch schon bewertete Versuche noch einmal vorlegen</label>
      <button class="co-go">Freitextaufgaben durchsuchen</button>
      <div class="co-progress co-hidden"><div class="co-bar"></div><span class="co-ptext"></span></div>
      <div class="co-result co-hidden">
        <p class="co-summary"></p>
        <p class="co-warn co-hidden"></p>
        <div class="co-prozentbox co-hidden"></div>
        <div class="co-zust co-hidden"></div>
        <button class="co-copy">📋 Prompt + Daten kopieren</button>
        <button class="co-copy2 co-zweit">📋 nur JSON</button>
        <p class="co-groesse"></p>
        <div class="co-list"></div>
      </div>
      <p class="co-error co-hidden"></p>
      <details class="co-details">
        <summary>Bewertungs-Prompt anpassen</summary>
        <p class="co-hinweis"><strong>Damit bewertet die KI die Schülerantworten.</strong>
        Hier steht der vollständige Prompt, den „📋 Prompt + Daten kopieren" verschickt —
        du kannst ihn lesen und ändern. „Standard einfügen" holt die mitgelieferte Fassung
        zurück. Der Platzhalter <code>[MOODLE_AI_COACH_DATEN]</code> wird beim Kopieren
        durch die Fragen und Antworten aus Moodle ersetzt.</p>
        <textarea class="co-prompt" rows="8"></textarea>
        <button class="co-promptstd co-zweit">Standard einfügen</button>
        <button class="co-promptsave co-zweit">Prompt speichern</button>
      </details>
    </div>

    <div class="co-body co-hidden" data-panel="eintrag">
      <p class="co-hinweis">Hier das Bewertungs-JSON der KI einfügen. Die Punkte rechnet
      die Erweiterung aus Inhalt und Fehlerzahl selbst.</p>
      <textarea class="co-json" rows="6" placeholder='{ "bewertungen": [ … ] }'></textarea>
      <label class="co-check"><input type="checkbox" class="co-ki" checked>
        KI-Hinweis ans Feedback anhängen</label>
      <p class="co-kivorschau"></p>
      <button class="co-pruef">🔍 Prüfen</button>
      <p class="co-pinfo co-hidden"></p>
      <div class="co-schreibknoepfe co-hidden">
        <button class="co-probe">Trockenlauf — nichts speichern</button>
        <button class="co-alle">Alle eintragen</button>
      </div>
      <div class="co-progress2 co-hidden"><div class="co-bar2"></div><span class="co-ptext2"></span></div>
      <p class="co-abschluss co-hidden"></p>
      <div class="co-log co-hidden"></div>
      <div class="co-vorschau"></div>
    </div>

    <div class="co-body co-hidden" data-panel="horizont">
      <p class="co-hinweis">Der Erwartungshorizont gehört in die Frage, nicht in die
      Erweiterung — einmal erstellt, gilt er dauerhaft und wandert beim Export mit.
      Hier wird er angelegt, wo er fehlt — oder für vorhandene neu geschrieben.</p>
      <div class="co-ohneliste"></div>
      <label class="co-check"><input type="checkbox" class="co-halle">
        Auch Fragen einbeziehen, die schon einen Horizont haben — <strong>der wird dabei
        überschrieben</strong></label>
      <label class="co-feldkopf">Was soll anders werden? (geht mit in den Prompt)</label>
      <textarea class="co-hwunsch" rows="3"
        placeholder="z. B.: Beim Löschsand müssen Metallbrände NICHT genannt werden — Name plus „löscht Brände“ reicht für 100 %."></textarea>
      <p class="co-hinweis">Ohne diese Zeilen sieht das Sprachmodell nur den bisherigen
      Horizont — und der sagt ja gerade das, was du ändern willst. Es schreibt ihn dann
      fort. Was hier steht, hat im Prompt Vorrang vor dem bisherigen Horizont.</p>
      <p class="co-hinweis">Beim Neuschreiben bekommt die KI den bisherigen Horizont mit,
      damit sie weiß, wovon sie abweicht. Ersetzt wird er erst, wenn du die Antwort in
      Schritt 2 einfügst und einträgst.</p>
      <p class="co-schritt">Schritt 1 — Prompt holen</p>
      <button class="co-hcopy">📋 Prompt für Erwartungshorizont kopieren</button>
      <details class="co-details">
        <summary>Horizont-Prompt anpassen</summary>
        <p class="co-hinweis"><strong>Damit schreibt die KI den Erwartungshorizont</strong>
        für Fragen, die noch keinen haben — also das, was später in der Frage steht und
        wonach der Bewertungs-Prompt dann bewertet. Hier steht der vollständige Prompt,
        den der Knopf oben kopiert. Der Platzhalter
        <code>[MOODLE_AI_COACH_AUFGABEN]</code> wird beim Kopieren durch die Aufgaben
        ohne Horizont ersetzt.</p>
        <textarea class="co-hprompt" rows="8"></textarea>
        <button class="co-hpromptstd co-zweit">Standard einfügen</button>
        <button class="co-hpromptsave co-zweit">Prompt speichern</button>
      </details>
      <p class="co-schritt">Schritt 2 — Antwort der KI einfügen</p>
      <textarea class="co-hjson" rows="5" placeholder='{ "horizonte": [ … ] }'></textarea>
      <button class="co-hpruef">🔍 Prüfen</button>
      <p class="co-hinfo co-hidden"></p>
      <div class="co-hliste"></div>
      <div class="co-progress3 co-hidden"><div class="co-bar3"></div><span class="co-ptext3"></span></div>
      <p class="co-habschluss co-hidden"></p>
      <div class="co-hlog co-hidden"></div>
      <div class="co-hknoepfe co-hidden">
        <button class="co-hprobe">Trockenlauf — nichts speichern</button>
        <button class="co-hschreib">In die Aufgaben eintragen</button>
      </div>
    </div>

    <div class="co-body co-hidden" data-panel="opt">
      <label class="co-label">Maximaler Abzug für Sprache und Ausdruck (% der Aufgabenpunkte)
        <input type="text" class="co-abzug" value="30">
      </label>
      <p class="co-abzuginfo"></p>
      <label class="co-check"><input type="checkbox" class="co-nurmarker">
        Nur Fragen bewerten, die „[moodle-ai-coach]" im Erwartungshorizont tragen</label>
      <p class="co-hinweis">Fragen, deren Horizont mit <code>[moodle-ai-grader]</code>
      beginnt, überspringt der Coach <strong>immer</strong> — dafür ist dieses Häkchen
      nicht nötig. Es entscheidet nur über Fragen <em>ohne</em> Marker: aus (Standard)
      werden sie bewertet und im Ergebnis gemeldet, an bleiben sie liegen. Leg es um,
      wenn dein Bestand vollständig markiert ist.</p>
      <label class="co-check"><input type="checkbox" class="co-kompakt">
        Kompakter Prompt (nur für KI mit eigenen Skills, z. B. Claude)</label>
      <p class="co-hinweis">Verweist für die Bewertungslogik auf die Skills
      „2-didaktik-bewertung“ und „3-moodle-erweiterungen“ statt sie komplett
      auszuschreiben – spart pro Aufruf mehrere Tausend Zeichen. <strong>Nur
      einschalten, wenn du sicher bist, dass die verwendete KI diese Skills wirklich
      kennt</strong> (z. B. dein eigener Claude-Cowork-Zugang). Andere Lehrkräfte
      oder andere KI-Systeme lassen dieses Häkchen aus – die bekommen automatisch den
      vollständigen Prompt. Wirkt nur auf den Bewertungs-Prompt in Reiter 1, nicht
      auf den Horizont-Prompt in Reiter 3.</p>
      <label class="co-label">KI-Hinweis unter dem Feedback
        <textarea class="co-kitext" rows="3"></textarea>
      </label>
      <p class="co-hinweis">Die beiden Prompts stehen dort, wo sie gebraucht werden:
      der <strong>Bewertungs-Prompt</strong> in Reiter 1 (damit bewertet die KI die
      Antworten), der <strong>Horizont-Prompt</strong> in Reiter 3 (damit schreibt sie
      den Erwartungshorizont für Fragen, die noch keinen haben) — jeweils unter
      „Prompt anpassen". In beiden Feldern steht der volle Text zum Lesen und Ändern.</p>
      <button class="co-optsave">Speichern</button>
      <button class="co-optreset co-zweit">Alles zurücksetzen</button>
      <p class="co-optinfo co-hidden"></p>
    </div>`,document.body.appendChild(L),L.querySelector(`.co-version`).textContent=e;let R=e=>L.querySelector(e),z=null,B=null,V=null,H=`coachErnte_`+r;function Oe(){try{t.storage.local.set({[H]:z})}catch{}}try{t.storage.local.get([H],e=>{let t=e&&e[H];if(t&&!z){z=t;let e=R(`.co-meta`);e&&(e.textContent+=` · ${(t.antworten||[]).length} Antworten aus einem früheren Durchlauf geladen`)}})}catch{}I.addEventListener(`click`,()=>L.classList.toggle(`co-hidden`)),R(`.co-close`).addEventListener(`click`,()=>L.classList.add(`co-hidden`));function U(e){L.querySelectorAll(`.co-tab`).forEach(t=>t.classList.toggle(`co-aktiv`,t.dataset.tab===e)),L.querySelectorAll(`[data-panel]`).forEach(t=>t.classList.toggle(`co-hidden`,t.dataset.panel!==e))}L.querySelectorAll(`.co-tab`).forEach(e=>{e.addEventListener(`click`,()=>U(e.dataset.tab))});function W(){let e=o(R(`.co-abzug`).value);return e===null||e<0?E.maxSprachabzug:Math.min(100,e)}function G(){let e=W();R(`.co-abzuginfo`).textContent=e===0?`Sprache zählt nicht für die Punkte. Das Sprachfeedback wird trotzdem geschrieben.`:`Höchstabzug ${c(e)} %. Ein Fehler kostet ${c(Math.round(e/3*10)/10)} %, zwei ${c(Math.round(e/2*10)/10)} %, drei ${c(Math.round(e*2/3*10)/10)} %, vier ${c(Math.round(e*5/6*10)/10)} %, ab fünf ${c(e)} %. Schwere Fehler zählen doppelt.`}function K(){let e=R(`.co-kivorschau`),t=(D.kiHinweisText||T).trim();if(!R(`.co-ki`).checked||!t){e.classList.add(`co-hidden`);return}e.classList.remove(`co-hidden`),e.textContent=`Angehängt wird: „`+t+`" (kursiv, kleine Schrift). Ändern unter ⚙.`}R(`.co-ki`).addEventListener(`change`,K),R(`.co-abzug`).addEventListener(`input`,G),R(`.co-abzug`).addEventListener(`change`,async()=>{G(),await k({maxSprachabzug:W()})}),R(`.co-nurmarker`).addEventListener(`change`,async e=>{await k({nurMitMarker:e.target.checked})}),ae().then(()=>{R(`.co-abzug`).value=c(D.maxSprachabzug??E.maxSprachabzug),R(`.co-kitext`).value=D.kiHinweisText||T,R(`.co-prompt`).value=D.promptOverride||N(),R(`.co-hprompt`).value=D.horizontPromptOverride||P(),R(`.co-nurmarker`).checked=!!D.nurMitMarker,R(`.co-kompakt`).checked=!!D.kompaktPrompt,G(),K()});function ke(e){let t=R(`.co-optinfo`);t.textContent=e,t.classList.remove(`co-hidden`),setTimeout(()=>t.classList.add(`co-hidden`),3e3)}R(`.co-optsave`).addEventListener(`click`,async()=>{await k({maxSprachabzug:W(),nurMitMarker:R(`.co-nurmarker`).checked,kompaktPrompt:R(`.co-kompakt`).checked,kiHinweisText:R(`.co-kitext`).value.trim()||T}),R(`.co-kitext`).value=D.kiHinweisText,G(),K(),ke(`Gespeichert ✓`),q(R(`.co-optsave`),`✓ Gespeichert`,`Speichern`),setTimeout(()=>U(`lesen`),900)});function q(e,t,n){e.textContent=t,setTimeout(()=>e.textContent=n,2e3)}R(`.co-promptstd`).addEventListener(`click`,()=>{R(`.co-prompt`).value=N(),q(R(`.co-promptstd`),`✓ eingefügt`,`Standard einfügen`)}),R(`.co-promptsave`).addEventListener(`click`,async()=>{let e=R(`.co-prompt`).value.trim(),t=e===N().trim()?``:e;await k({promptOverride:t}),q(R(`.co-promptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),R(`.co-hpromptstd`).addEventListener(`click`,()=>{R(`.co-hprompt`).value=P(),q(R(`.co-hpromptstd`),`✓ eingefügt`,`Standard einfügen`)}),R(`.co-hpromptsave`).addEventListener(`click`,async()=>{let e=R(`.co-hprompt`).value.trim(),t=e===P().trim()?``:e;await k({horizontPromptOverride:t}),q(R(`.co-hpromptsave`),t?`✓ eigener Prompt gespeichert`:`✓ Standard`,`Prompt speichern`)}),R(`.co-optreset`).addEventListener(`click`,async()=>{await k({...E}),R(`.co-abzug`).value=c(E.maxSprachabzug),R(`.co-nurmarker`).checked=E.nurMitMarker,R(`.co-kompakt`).checked=E.kompaktPrompt,R(`.co-kitext`).value=T,R(`.co-prompt`).value=N(),R(`.co-hprompt`).value=P(),G(),K(),ke(`Auf Standard zurückgesetzt — auch die Prompts in Reiter 1 und 3.`)}),R(`.co-meta`).textContent=(document.title||``).replace(/\s*\|.*$/,``).trim()||`Manuelle Bewertung`,R(`.co-go`).addEventListener(`click`,async()=>{let e=R(`.co-go`);e.disabled=!0,e.textContent=`läuft …`,R(`.co-error`).classList.add(`co-hidden`),R(`.co-result`).classList.add(`co-hidden`),R(`.co-progress`).classList.remove(`co-hidden`);try{z=await ge((e,t,n)=>{R(`.co-bar`).style.width=Math.round(e/t*100)+`%`,R(`.co-ptext`).textContent=`${e} / ${t} Fragen · ${n} Antworten`},R(`.co-bereits`).checked);let e=z.meta,t=Object.values(z.fragen).filter(e=>e.horizont),n=Object.values(z.fragen).filter(e=>!e.horizont),r=Object.values(z.fremde||{}),i=Object.values(z.fragen).filter(e=>e.horizont_aus_fassung).length;R(`.co-summary`).textContent=`${e.antworten} Antworten auf ${Object.keys(z.fragen).length} Freitextfragen · ${t.length} mit Horizont, ${n.length} ohne · ${e.uebersprungen} übersprungen`+(r.length?` · ${r.length} nicht für den Coach`:``)+(i?` · ${i} Horizont(e) aus der neuesten Fragenfassung geholt`:``);let a=R(`.co-warn`);n.length?(a.classList.remove(`co-hidden`),a.textContent=`⚠ ${n.length} Frage(n) haben keinen Erwartungshorizont. Sie sind im Prompt nicht enthalten — leg ihn in Reiter 3 an.`):a.classList.add(`co-hidden`);function o(){let e=R(`.co-prozentbox`);e.innerHTML=``;let t=D.maxSprachabzug??E.maxSprachabzug,n=Object.values(z.fragen).filter(e=>e.horizont&&e.horizontProzent!=null&&e.horizontProzent!==t);if(!n.length){e.classList.add(`co-hidden`);return}e.classList.remove(`co-hidden`),e.appendChild(f(`div`,`co-zustkopf`,`⚠ ${n.length} Frage(n) tragen im Horizont eine andere Rechtschreibungs-Prozentzahl als aktuell eingestellt (${c(t)} %):`)),n.forEach(t=>e.appendChild(f(`div`,`co-logzeile`,`${t.name} — Horizont: ${c(t.horizontProzent)} %`))),e.appendChild(f(`div`,`co-hinweis`,O?`Es gilt gerade überall die eingestellte Prozentzahl (${c(t)} %).`:`Es gilt gerade je Frage der Wert aus dem Horizont — so, wie beim Erstellen des Erwartungshorizonts bewusst festgelegt.`));let r=f(`button`,`co-marker co-zweit`,O?`Stattdessen die Horizont-Werte verwenden`:`Stattdessen überall ${c(t)} % verwenden`);r.addEventListener(`click`,()=>{O=!O,o()}),e.appendChild(r)}o();let l=R(`.co-zust`);l.innerHTML=``;let u=Object.values(z.fragen).filter(e=>e.horizont&&!e.zustaendig);if(r.length||u.length){l.classList.remove(`co-hidden`);let e=r.filter(e=>e.grund===`grader`),t=r.filter(e=>e.grund!==`grader`);if(e.length&&(l.appendChild(f(`div`,`co-zustkopf`,`↷ ${e.length} Frage(n) sind für den Moodle AI Grader gebaut — übersprungen.`)),e.forEach(e=>l.appendChild(f(`div`,`co-logzeile`,e.name)))),t.length&&(l.appendChild(f(`div`,`co-zustkopf`,`↷ ${t.length} Frage(n) ohne Marker — übersprungen, weil „nur mit Marker" eingeschaltet ist (⚙).`)),t.forEach(e=>l.appendChild(f(`div`,`co-logzeile`,e.name)))),u.length){l.appendChild(f(`div`,`co-zustkopf`,`⚠ ${u.length} Frage(n) haben einen Horizont, aber keinen Marker — sie wurden mitbewertet. Trag den Marker nach, dann ist die Zuständigkeit dauerhaft geklärt.`)),u.forEach(e=>l.appendChild(f(`div`,`co-logzeile`,e.name)));let e=`${y} in ${u.length} Frage(n) nachtragen`,t=f(`button`,`co-marker co-zweit`,e),n=!1,r=null;t.addEventListener(`click`,async()=>{if(!n){n=!0,t.textContent=`Wirklich? Ändert die Fragen — noch einmal klicken`,r=setTimeout(()=>{n&&(n=!1,t.textContent=e)},8e3);return}r&&=(clearTimeout(r),null),t.disabled=!0;let i=f(`div`,`co-marklog`);l.appendChild(i);let a=0,o=[];for(let e=0;e<u.length;e++){let n=u[e];t.textContent=`Trage nach … ${e+1} von ${u.length}: ${n.name}`;let r=f(`div`,`co-logzeile`,`… ${n.name}`);i.appendChild(r),i.scrollTop=i.scrollHeight;try{await Te(n.qid),a++,r.textContent=`✓ ${n.name}`}catch(e){o.push(`${n.name}: ${e.message}`),r.textContent=`✗ ${n.name}: ${e.message}`,r.classList.add(`co-logfehler`)}}t.textContent=`${a} nachgetragen`+(o.length?`, ${o.length} fehlgeschlagen`:``),a&&l.appendChild(f(`div`,`co-logzeile`,`Bitte „Freitextaufgaben durchsuchen" noch einmal laufen lassen — dann liest die Erweiterung den neuen Stand.`))}),l.appendChild(t);let i=f(`button`,`co-hneu co-zweit`,`Horizont neu schreiben`);i.title=`Springt zu Reiter 3 und nimmt diese Fragen in den Prompt auf`,i.addEventListener(`click`,()=>{R(`.co-halle`).checked=!0,Q(),U(`horizont`),R(`.co-hcopy`).scrollIntoView({block:`nearest`})}),l.appendChild(i)}}else l.classList.add(`co-hidden`);let d=L.querySelector(`.co-badge`);d.classList.toggle(`co-hidden`,!n.length),d.textContent=n.length||``;let p=R(`.co-list`);p.innerHTML=``,Object.values(z.fragen).forEach(e=>{let t=f(`div`,`co-qname`);t.appendChild(f(`span`,e.horizont?`co-ok`:`co-fehlt`,e.horizont?`✓`:`✗`)),t.appendChild(f(`span`,`co-qtext`,` ${e.name} · ${s(e.max)} P.`)),p.appendChild(t),z.antworten.filter(t=>t.qid===e.qid).forEach(e=>{let t=f(`a`,`co-row`);t.href=_(e),t.target=`_blank`,t.rel=`noopener`,t.appendChild(f(`span`,`co-nr`,`#`+e.nr)),t.appendChild(f(`span`,`co-ans`,e.antwort.slice(0,90))),p.appendChild(t)})});let m=R(`.co-ohneliste`);m.innerHTML=``,n.length?(m.appendChild(f(`div`,`co-fehlendkopf`,`Ohne Erwartungshorizont:`)),n.forEach(e=>m.appendChild(f(`div`,`co-logzeile`,`${e.name} — ${e.aufgabe.slice(0,90)}`)))):(m.appendChild(f(`div`,`co-fehlendkopf`,`Alle Fragen haben einen Horizont. Willst du einen neuen für die Aufgaben schreiben?`)),m.appendChild(f(`div`,`co-logzeile`,`Setz dazu unten das Häkchen — der vorhandene Horizont wird beim Eintragen überschrieben.`))),!n.length&&t.length&&(R(`.co-halle`).checked=!0),Q(),Oe();let h=F(z).length;R(`.co-groesse`).textContent=`Prompt ≈ ${Math.round(h/1e3)} 000 Zeichen`,R(`.co-result`).classList.remove(`co-hidden`),z.fehler.length&&(R(`.co-error`).textContent=z.fehler.length+` Frage(n) konnten nicht geladen werden.`,R(`.co-error`).classList.remove(`co-hidden`))}catch(e){R(`.co-error`).textContent=`Fehler: `+e.message,R(`.co-error`).classList.remove(`co-hidden`)}finally{R(`.co-progress`).classList.add(`co-hidden`),e.disabled=!1,e.textContent=`Freitextaufgaben durchsuchen`}});function Ae(e){let t={meta:{...e.meta},fragen:{},antworten:[]};Object.entries(e.fragen).forEach(([e,n])=>{n.horizont&&(t.fragen[e]=n)});let n=new Set(Object.values(t.fragen).map(e=>e.qid));return t.antworten=e.antworten.filter(e=>n.has(e.qid)),t.meta.antworten=t.antworten.length,t}function J(e,t){let n=R(e);n.textContent=`✓ kopiert`,setTimeout(()=>n.textContent=t,2e3)}R(`.co-copy`).addEventListener(`click`,async()=>{z&&(await v(F(Ae(z))),J(`.co-copy`,`📋 Prompt + Daten kopieren`))}),R(`.co-copy2`).addEventListener(`click`,async()=>{z&&(await v(JSON.stringify(Ae(z),null,1)),J(`.co-copy2`,`📋 nur JSON`))});let je=`Zu diesem Test liegen keine ausgelesenen Daten vor. Bitte zuerst in Reiter 1 „Freitextaufgaben durchsuchen" laufen lassen.`;function Me(e){let t=e.value.replace(/^\s*```(?:json)?/,``).replace(/```\s*$/,``).trim();if(!t)throw Error(`Das Feld ist leer.`);if(!/^[{[]/.test(t))throw Error(`Das sieht nicht nach JSON aus — der Text muss mit { beginnen.`);return JSON.parse(t)}R(`.co-pruef`).addEventListener(`click`,()=>{let e=R(`.co-pinfo`);e.classList.remove(`co-hidden`),R(`.co-schreibknoepfe`).classList.add(`co-hidden`),R(`.co-abschluss`).classList.add(`co-hidden`),R(`.co-log`).classList.add(`co-hidden`),R(`.co-vorschau`).innerHTML=``,B=null;try{if(!z)throw Error(je);let t=Me(R(`.co-json`)).bewertungen||[];if(!t.length)throw Error(`Keine „bewertungen" im JSON gefunden.`);let n=new Map(z.antworten.map(e=>[e.qubaid+`|`+e.slot,e])),r=[];t.forEach((e,t)=>{let i=t+1;if(e.qubaid==null||e.slot==null)throw Error(`Eintrag ${i}: „qubaid" oder „slot" fehlt.`);let a=n.get(String(e.qubaid)+`|`+String(e.slot));if(!a)throw Error(`Eintrag ${i}: zu qubaid ${e.qubaid} / slot ${e.slot} gibt es keine ausgelesene Antwort. Stammt das JSON zu diesem Durchlauf?`);let o=Number(e.inhalt);if(isNaN(o)||o<0||o>100)throw Error(`Eintrag ${i}: „inhalt" ist kein Prozentwert (${e.inhalt}).`);let l=z.fragen&&z.fragen[a.frage]||{},f=le(a.max,o,e.fehler,ie(l)),p=o<100?d(l.horizont):``,m=u(e.rueckmeldung,p,{inhalt:f.inhaltPunkte,inhaltMax:a.max,abzug:f.abzugPunkte,gewicht:f.gewicht})||String(e.text||``).trim();r.push({...a,inhalt:o,fehler:e.fehler||[],text:m,punkte:f.punkte,gewicht:f.gewicht,abzug:f.abzug,rechnung:`Inhalt ${c(o)} % = ${s(f.inhaltPunkte)} · ${f.gewicht} Fehlerpunkt(e) → −${c(Math.round(f.abzug*10)/10)} % · = ${s(f.punkte)} von ${s(a.max)}`})}),B=r;let i=r.filter(e=>!e.text).length,a=new Set(r.map(e=>e.slot+`|`+e.qid)).size;e.className=`co-pinfo co-ok`,e.textContent=`✓ ${r.length} Bewertungen auf ${a} Fragenseiten — bereit. Punkte und Abzug wurden aus Inhalt und Fehlerzahl berechnet.`+(i?` ⚠ ${i} Eintrag/Einträge ohne Rückmeldungstext.`:``);let o=f(`div`,`co-rechnung`);r.forEach(e=>{let t=f(`a`,`co-logzeile co-vorschauzeile`),n=_(e);n&&(t.href=n,t.target=`_blank`,t.rel=`noopener`),t.appendChild(f(`span`,`co-vfrage`,e.frage)),t.appendChild(f(`span`,`co-vans`,`„`+e.antwort.slice(0,60)+`"`)),t.appendChild(f(`span`,`co-vpkt`,e.rechnung)),o.appendChild(t)}),R(`.co-vorschau`).appendChild(o),R(`.co-schreibknoepfe`).classList.remove(`co-hidden`),R(`.co-schreibknoepfe`).scrollIntoView({block:`nearest`})}catch(t){e.className=`co-pinfo co-error`,e.textContent=`Fehler: `+t.message}});function Ne(e){return(t,n)=>{let r=f(n?`a`:`div`,`co-logzeile`,t);n&&(r.href=n,r.target=`_blank`,r.rel=`noopener`),(t.startsWith(`✗`)||t.startsWith(`⚠`))&&r.classList.add(`co-logfehler`),e.appendChild(r),e.scrollTop=e.scrollHeight}}async function Pe(e){if(!B)return;let t=R(`.co-log`),n=R(`.co-abschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),R(`.co-progress2`).classList.remove(`co-hidden`),R(`.co-probe`).disabled=R(`.co-alle`).disabled=!0,R(`.co-progress2`).scrollIntoView({block:`nearest`});let r=Ne(t),i=(e,t)=>{R(`.co-bar2`).style.width=Math.round(e/t*100)+`%`,R(`.co-ptext2`).textContent=`${e} / ${t} Fragenseiten`};try{let a=e?await ve(B,r,i):await xe(B,R(`.co-ki`).checked,r,i);if(t.prepend(f(`div`,`co-logkopf`,e?`${a.ok} Felder gefunden · ${a.fehler} fehlen · ${a.gruppen} Seiten geprüft`:`${a.ok} eingetragen und geprüft · ${a.fehler} fehlgeschlagen · ${a.gruppen} Seiten`+(a.versuche>1?` · ${a.versuche} Versuche gebraucht`:``))),n.classList.remove(`co-hidden`),a.fehler>0)n.className=`co-abschluss co-abfehler`,n.textContent=e?`⚠ ${a.fehler} Feld/Felder fehlen. Trag noch nichts ein — stammt das JSON zu diesem Durchlauf?`:`⚠ ${a.fehler} Eintrag/Einträge sind nicht angekommen. Sieh sie im Protokoll nach.`,e||(R(`.co-alle`).textContent=`Erneut versuchen`);else if(n.className=`co-abschluss co-abok`,n.textContent=e?`✓ Alles vorhanden — ${a.ok} Felder auf ${a.gruppen} Seiten. Du kannst eintragen.`:`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`,e||(R(`.co-alle`).textContent=`Alle eintragen`),!e){let e=4,t=setInterval(()=>{e--,n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler. Fenster schließt in ${e} …`,e<=0&&(clearInterval(t),L.classList.add(`co-hidden`),n.textContent=`✓ Fertig — ${a.ok} Einträge auf ${a.gruppen} Seiten, keine Fehler.`)},1e3);L.addEventListener(`click`,()=>clearInterval(t),{once:!0})}n.scrollIntoView({block:`nearest`})}catch(e){r(`✗ Abbruch: `+e.message)}finally{R(`.co-progress2`).classList.add(`co-hidden`),R(`.co-probe`).disabled=R(`.co-alle`).disabled=!1}}R(`.co-probe`).addEventListener(`click`,()=>Pe(!0)),R(`.co-alle`).addEventListener(`click`,()=>Pe(!1));function Y(){if(!z)return[];let e=Object.values(z.fragen);return R(`.co-halle`).checked?e:e.filter(e=>!e.horizont)}let X=`coachWunsch_`+r;function Z(){let e=L.querySelector(`.co-hwunsch`);return e?e.value.trim():``}try{t.storage.local.get([X],e=>{let t=e&&e[X];t&&!Z()&&(L.querySelector(`.co-hwunsch`).value=t)})}catch{}L.querySelector(`.co-hwunsch`).addEventListener(`input`,()=>{try{t.storage.local.set({[X]:Z()})}catch{}});function Q(){let e=Y().length,t=R(`.co-halle`).checked;R(`.co-hcopy`).textContent=t?`📋 Prompt zum Neuschreiben kopieren (${e} Frage${e===1?``:`n`})`:`📋 Prompt für Erwartungshorizont kopieren`}R(`.co-halle`).addEventListener(`change`,Q),R(`.co-hcopy`).addEventListener(`click`,async()=>{if(!z){R(`.co-hinfo`).className=`co-hinfo co-error`,R(`.co-hinfo`).classList.remove(`co-hidden`),R(`.co-hinfo`).textContent=je;return}let e=Y();if(!e.length){R(`.co-hinfo`).className=`co-hinfo`,R(`.co-hinfo`).classList.remove(`co-hidden`),R(`.co-hinfo`).textContent=`Es fehlt kein Horizont. Setz das Häkchen darüber, wenn du die vorhandenen neu schreiben lassen willst.`;return}await v(De(e));let t=R(`.co-hcopy`).textContent;J(`.co-hcopy`,t)}),R(`.co-hpruef`).addEventListener(`click`,()=>{let e=R(`.co-hinfo`);e.classList.remove(`co-hidden`),R(`.co-hknoepfe`).classList.add(`co-hidden`),R(`.co-habschluss`).classList.add(`co-hidden`),R(`.co-hlog`).classList.add(`co-hidden`),R(`.co-hliste`).innerHTML=``,V=null;try{let t=Me(R(`.co-hjson`)).horizonte||[];if(!t.length)throw Error(`Keine „horizonte" im JSON gefunden.`);let n=z?new Map(Object.values(z.fragen).map(e=>[String(e.qid),e])):new Map;V=t.map((e,t)=>{if(!e.qid)throw Error(`Horizont ${t+1}: „qid" fehlt.`);let r=n.get(String(e.qid)),i=String(e.text||``).trim();if(!i)throw Error(`Horizont ${t+1}: „text" ist leer.`);return{qid:String(e.qid),frage:e.frage||(r?r.name:`Frage `+e.qid),text:i,bekannt:!!r,hatteHorizont:!!(r&&r.horizont)}});let r=V.filter(e=>e.hatteHorizont).length,i=V.filter(e=>!e.bekannt).length;e.className=`co-hinfo co-ok`,e.textContent=`✓ ${V.length} Horizont(e) gelesen.`+(i?` ⚠ ${i} gehören zu keiner ausgelesenen Frage.`:``)+(r?` ⚠ ${r} würden einen vorhandenen Horizont überschreiben.`:``);let a=R(`.co-hliste`);V.forEach((e,t)=>{let n=f(`div`,`co-hcard`);n.appendChild(f(`div`,`co-fehlendkopf`,`${e.frage}  ·  qid ${e.qid}`));let r=f(`textarea`,`co-htext`);r.value=e.text,r.rows=10,r.addEventListener(`input`,()=>{V[t].text=r.value}),n.appendChild(r),a.appendChild(n)}),R(`.co-hknoepfe`).classList.remove(`co-hidden`),e.scrollIntoView({block:`nearest`})}catch(t){e.className=`co-hinfo co-error`,e.textContent=`Fehler: `+t.message}});async function $(e){if(!V||!V.length)return;let t=R(`.co-hlog`),n=R(`.co-habschluss`);t.innerHTML=``,t.classList.remove(`co-hidden`),n.classList.add(`co-hidden`),R(`.co-progress3`).classList.remove(`co-hidden`),R(`.co-hprobe`).disabled=R(`.co-hschreib`).disabled=!0,R(`.co-progress3`).scrollIntoView({block:`nearest`});let r=Ne(t),i=0,a=0,o=0;try{for(let t of V){try{let n=await we(t.qid,t.text,e);i++,r(e?`✓ ${t.frage} — Feld „${n.feld}" vorhanden`+(n.vorher&&n.vorher.replace(/<[^>]*>/g,``).trim()?` (enthält schon Text!)`:``):`✓ ${t.frage} — Horizont eingetragen`)}catch(e){a++,r(`✗ ${t.frage}: ${e.message}`)}o++,R(`.co-bar3`).style.width=Math.round(o/V.length*100)+`%`,R(`.co-ptext3`).textContent=`${o} / ${V.length} Fragen`}t.prepend(f(`div`,`co-logkopf`,e?`${i} Fragen erreichbar · ${a} nicht`:`${i} Horizonte eingetragen · ${a} fehlgeschlagen`)),n.classList.remove(`co-hidden`),n.className=`co-habschluss `+(a?`co-abfehler`:`co-abok`),n.textContent=a?`⚠ ${a} Frage(n) konnten nicht geschrieben werden. Sieh ins Protokoll.`:e?`✓ Alle ${i} Fragen sind erreichbar und haben das Feld. Du kannst eintragen.`:`✓ ${i} Horizonte stehen jetzt in den Fragen. Führe Reiter 1 noch einmal aus, dann sind sie im Bewertungs-Prompt dabei.`,n.scrollIntoView({block:`nearest`})}finally{R(`.co-progress3`).classList.add(`co-hidden`),R(`.co-hprobe`).disabled=R(`.co-hschreib`).disabled=!1}}R(`.co-hprobe`).addEventListener(`click`,()=>$(!0)),R(`.co-hschreib`).addEventListener(`click`,()=>{let e=V?V.length:0;if(!e)return;let t=R(`.co-habschluss`);t.classList.remove(`co-hidden`),t.className=`co-habschluss co-abfrage`,t.innerHTML=``,t.appendChild(f(`div`,null,`Der Erwartungshorizont wird in ${e} Frage(n) der Fragensammlung geschrieben. Das ändert die Fragen selbst, nicht nur eine Bewertung.`));let n=f(`button`,`co-jetzt`,`Ja, in ${e} Frage(n) eintragen`);t.appendChild(n),n.addEventListener(`click`,()=>{t.classList.add(`co-hidden`),$(!1)})})}var r=e({matches:[`*://*/*mod/quiz/report.php*`],runAt:`document_idle`,cssInjectionMode:`manifest`,main(){n()}}),i={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},a=class e extends Event{static EVENT_NAME=o(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function o(e){return`${t?.runtime?.id}:content:${e}`}var s=typeof globalThis.navigation?.addEventListener==`function`;function c(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),s?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new a(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new a(e,t)),t=e)},1e3))}}}var l=class e{static SCRIPT_STARTED_MESSAGE_TYPE=o(`wxt:content-script-started`);id;abortController;locationWatcher=c(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?o(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),i.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},u={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=r;return await e(new l(`content`,t))}catch(e){throw u.error(`The content script "content" crashed on startup!`,e),e}})()})();